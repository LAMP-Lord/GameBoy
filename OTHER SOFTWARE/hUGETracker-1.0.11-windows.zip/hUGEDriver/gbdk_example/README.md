This is a simple example of how to use hUGEDriver in your GBDK-2020 game.

Make sure you have both GBDK and RGBDS in your path, then run `build.bat` to build a .gb file which plays some music!

You can run `build\gbdk_player_example.gb` in your favorite Game Boy emulator.
