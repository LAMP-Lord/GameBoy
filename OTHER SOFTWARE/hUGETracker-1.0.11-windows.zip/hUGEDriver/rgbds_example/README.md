This is a simple example of how to use hUGEDriver in your game.

Make sure you have RGBDS in your path, then run `build.bat` to build a .gb file which plays some music!

You can run `output.gb` in your favorite Game Boy emulator.
